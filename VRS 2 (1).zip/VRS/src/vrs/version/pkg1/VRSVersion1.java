/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vrs.version.pkg1;
import Clients_comparisons.CompareWithName;
import Manage_Clients.Client;
import Manage_Clients.Clients_collection;
import static java.lang.System.*;
import static Manage_Clients.Clients_collection.Clientspath;
import VRS_GUIS.VRSFrame;
import java.io.File;
import java.io.FileNotFoundException;

/**
 *
 * @author zouin
 */
public class VRSVersion1 {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        VRSFrame window = new VRSFrame();
        
        window.setVisible(true);
    
        // TODO code application logic here
    }
    
}
