/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clients_comparisons;
import Manage_Clients.Client;
import java.util.Comparator;
/**
 *
 * @author zouin
 */
public class CompareWithName implements Comparator<Client>{
    @Override
    public int compare(Client o1, Client o2) {
        return o1.getCompany_name().compareTo(o2.getCompany_name());
    }
}
