/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_Clients;
import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author zouin
 */
public class Client implements Serializable{
   
    private String Company_name;
    private String Liaison_name;
    private String Liaison_phone;
    private String Company_phone;
    private String Company_address;
    private String Company_email;

    public Client(String companyName,String liaisonName,String liaisonPhone,String companyPhone,String companyAddress,String companyEmail){
        
        setCompany_name(companyName);
        setLiaison_name(liaisonName);
        setLiaison_phone(liaisonPhone);
        setCompany_phone(companyPhone);
        setCompany_address(companyAddress);
        setCompany_email(companyEmail);
        
    }
   
    
    /**
     * @return the Client_ID
     */
    

    /**
     * @return the Company_name
     */
    public String getCompany_name() {
        return Company_name;
    }

    /**
     * @param Company_name the Company_name to set
     */
    public void setCompany_name(String Company_name) {
        this.Company_name = Company_name;
    }

    /**
     * @return the Liaison_name
     */
    public String getLiaison_name() {
        return Liaison_name;
    }

    /**
     * @param Liaison_name the Liaison_name to set
     */
    public void setLiaison_name(String Liaison_name) {
        this.Liaison_name = Liaison_name;
    }

    /**
     * @return the Liaison_phone
     */
    public String getLiaison_phone() {
        return Liaison_phone;
    }

    /**
     * @param Liaison_phone the Liaison_phone to set
     */
    public void setLiaison_phone(String Liaison_phone) {
        this.Liaison_phone = Liaison_phone;
    }

    /**
     * @return the Company_phone
     */
    public String getCompany_phone() {
        return Company_phone;
    }

    /**
     * @param Company_phone the Company_phone to set
     */
    public void setCompany_phone(String Company_phone) {
        this.Company_phone = Company_phone;
    }

    /**
     * @return the Company_address
     */
    public String getCompany_address() {
        return Company_address;
    }

    /**
     * @param Company_address the Company_address to set
     */
    public void setCompany_address(String Company_address) {
        this.Company_address = Company_address;
    }

    /**
     * @return the Company_email
     */
    public String getCompany_email() {
        return Company_email;
    }

    /**
     * @param Company_email the Company_email to set
     */
    public void setCompany_email(String Company_email) {
        this.Company_email = Company_email;
    }
    
    @Override
   public String toString(){
       return getCompany_name()+getLiaison_name()+getCompany_phone()+getLiaison_phone()+getCompany_address()+getCompany_email();
   }
   
    @Override
    public boolean equals(Object obj) {
        return (obj != null
                && (obj instanceof Client)
                && ((Client) obj).getCompany_name().equalsIgnoreCase(Company_name));
    }
    
    
    
}
