/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_Clients;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import Manage_Clients.Client;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
/**
 *
 * @author zouin
 */
public class Clients_collection {
    public static final String Clientspath=System.getProperty("user.home")+File.separator+"VRS"+File.separator+"clients.ser";
    List<Client> clients;
    public Clients_collection() {
        this.clients = new LinkedList<Client>();
    }

    public boolean addClient(Client c) {
         return clients.add(c);
         
    }

    public boolean removeClient(Client c) {
        return clients.remove(c);
    }
    public void modifyClient(Client Companyname, Client newClient) {
        ListIterator<Client> iter = clients.listIterator();
        while (iter.hasNext()) {
            Client c = iter.next();
            if (c.getCompany_name().equals(Companyname.getCompany_name())) {
                iter.set(newClient);
            }
        }
    }
    public ArrayList<Client> findClientWithName(String name) {
        ArrayList<Client> results = new ArrayList<Client>();
        ListIterator<Client> iter = clients.listIterator();
        while (iter.hasNext()) {
            Client c = iter.next();
            if (c.getCompany_name().equals(name)) {
                results.add(c);
            }
        }
        return results;
    }
    public void sortClients(Comparator comp) {
        Collections.sort(clients, comp);
    }
    @Override
    public String toString() {
        String str = "";
        ListIterator<Client> iter = clients.listIterator();
        while (iter.hasNext()) {
            Client c = iter.next();
            str += c.toString() + "\n";
        }
        return str;
    }
    public List<Client> getClients() {
        return clients;
    }
    public void save(String filename){
        FileOutputStream fos=null;
        ObjectOutputStream objOut=null;
        try{
            fos=new FileOutputStream(filename);
            objOut=new ObjectOutputStream(fos);
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        try{
            objOut.writeObject(clients);
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
    }
    public void load(String filename) throws FileNotFoundException {
        FileInputStream fis=null;
        ObjectInputStream objIn=null;
        
        try{
            fis=new FileInputStream(filename);
            objIn=new ObjectInputStream(fis);
        }
        catch(FileNotFoundException ex){
            throw ex;
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        try{
            clients=(List<Client>) objIn.readObject();
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
            
        }
        catch(EOFException eof){
            eof.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
    }
}
