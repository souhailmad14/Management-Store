/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_Products;

/**
 *
 * @author zouin
 */
public class Product {
    private String product_id;
    private String product_name;
    private String product_category;
    private int quantity;
    private double price_ht;
    private double tax_percentage;
    private double price_ttc;
    private String expiration_date;
    private int threshold_quantity;

    /**
     * @return the product_id
     */
    public Product(String id,String name,String category,int quantity,double prix_ht,double tax,double prix_ttc,String expiration,int threshold){
            setProduct_id(id);
            setProduct_name(name);
            setProduct_category(category);
            setQuantity(quantity);
            setPrice_ht(prix_ht);
            setTax_percentage(tax);
            setPrice_ttc(prix_ttc);
            setExpiration_date(expiration);
            setThreshold_quantity(threshold);


}
    public String getProduct_id() {
        return product_id;
    }

    /**
     * @param product_id the product_id to set
     */
    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    /**
     * @return the product_name
     */
    public String getProduct_name() {
        return product_name;
    }

    /**
     * @param product_name the product_name to set
     */
    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    /**
     * @return the product_category
     */
    public String getProduct_category() {
        return product_category;
    }

    /**
     * @param product_category the product_category to set
     */
    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the price_ht
     */
    public double getPrice_ht() {
        return price_ht;
    }

    /**
     * @param price_ht the price_ht to set
     */
    public void setPrice_ht(double price_ht) {
        this.price_ht = price_ht;
    }

    /**
     * @return the tax_percentage
     */
    public double getTax_percentage() {
        return tax_percentage;
    }

    /**
     * @param tax_percentage the tax_percentage to set
     */
    public void setTax_percentage(double tax_percentage) {
        this.tax_percentage = tax_percentage;
    }

    /**
     * @return the price_ttc
     */
    public double getPrice_ttc() {
        return price_ttc;
    }

    /**
     * @param price_ttc the price_ttc to set
     */
    public void setPrice_ttc(double price_ttc) {
        this.price_ttc = price_ttc;
    }

    /**
     * @return the expiration_date
     */
    public String getExpiration_date() {
        return expiration_date;
    }

    /**
     * @param expiration_date the expiration_date to set
     */
    public void setExpiration_date(String expiration_date) {
        this.expiration_date = expiration_date;
    }

    /**
     * @return the threshold_quantity
     */
    public int getThreshold_quantity() {
        return threshold_quantity;
    }

    /**
     * @param threshold_quantity the threshold_quantity to set
     */
    public void setThreshold_quantity(int threshold_quantity) {
        this.threshold_quantity = threshold_quantity;
    }
    @Override
    public String toString(){
        return getProduct_id()+" "+getProduct_name()+" "+getProduct_category()+" "+getQuantity()+" "+getPrice_ht()+" "+getTax_percentage()+" "+getPrice_ttc()+" "+getExpiration_date()+" "+getThreshold_quantity()+" ";
    }
   @Override
    public boolean equals(Object obj) {
        return (obj != null
                && (obj instanceof Product)
                && ((Product) obj).getProduct_id().equalsIgnoreCase(product_id));
    }
}


