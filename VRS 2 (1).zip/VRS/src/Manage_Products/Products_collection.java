/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_Products;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
 *
 * @author zouin
 */
public class Products_collection {
    public static final String Productspath=System.getProperty("user.home")+File.separator+"VRS"+File.separator+"products.ser";
    private List<Product> products;
    
    public Products_collection(){
        this.products = new LinkedList<Product>();
    }
    

    /**
     * @return the products
     */
    public List<Product> getProducts() {
        return products;
    }

    /**
     * @param products the products to set
     */
    public void setProducts(List<Product> products) {
        this.products = products;
    }
    public boolean addProduct(Product p) {
         return products.add(p);
         
    }
        public boolean removeProduct(Product p) {
        return products.remove(p);
    }
        public void modifyClient(Product Productname, Product newProduct) {
        ListIterator<Product> iter = products.listIterator();
        while (iter.hasNext()) {
            Product c = iter.next();
            if (c.getProduct_id().equals(Productname.getProduct_id())) {
                iter.set(newProduct);
            }
        }
    }
        public ArrayList<Product> findProductWithID(String id) {
        ArrayList<Product> results = new ArrayList<>();
        ListIterator<Product> iter = products.listIterator();
        while (iter.hasNext()) {
            Product p = iter.next();
            if (p.getProduct_id().equals(id)) {
                results.add(p);
            }
        }
        return results;
    }
        public void sortProducts(Comparator comp) {
        Collections.sort(products, comp);
    }
        @Override
    public String toString() {
        String str = "";
        ListIterator<Product> iter = products.listIterator();
        while (iter.hasNext()) {
            Product p = iter.next();
            str += p.toString() + "\n";
        }
        return str;
    }
    public void save(String filename){
        FileOutputStream fos=null;
        ObjectOutputStream objOut=null;
        try{
            fos=new FileOutputStream(filename);
            objOut=new ObjectOutputStream(fos);
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        try{
            objOut.writeObject(products);
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
        
    }
    public void load(String filename) throws FileNotFoundException {
        FileInputStream fis=null;
        ObjectInputStream objIn=null;
        
        try{
            fis=new FileInputStream(filename);
            objIn=new ObjectInputStream(fis);
        }
        catch(FileNotFoundException ex){
            throw ex;
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        try{
            products=(List<Product>) objIn.readObject();
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
            
        }
        catch(EOFException eof){
            eof.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
    }
    
    
       
        
}

